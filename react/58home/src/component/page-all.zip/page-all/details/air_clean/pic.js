import styled from 'styled-components';

export const Pic = styled.div`
  position: relative;
  
  width:10rem;
  background-color: #fff;
  img{
      width: 10rem;
  }
    
`;
