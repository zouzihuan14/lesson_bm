import './title.css'
import React from 'react';
export default ()=>{
    return(
        <div className='detail_title'>
            <div className='one'> 空调清洗</div> 
        </div>
    )
}
